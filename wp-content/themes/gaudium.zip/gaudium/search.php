<?php get_header(); ?>
<?php get_template_part('main-content', get_post_format()); ?>
<?php get_footer(); ?>
