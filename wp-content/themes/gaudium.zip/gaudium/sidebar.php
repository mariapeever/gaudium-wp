<aside class="col-sm-12 col-md-3 bspace-1">
    <?php if(is_active_sidebar('sidebar')): ?>
        <?php dynamic_sidebar('sidebar'); ?>
    <?php endif; ?>
</aside>